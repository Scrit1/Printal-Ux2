  createProduct(
    "Cube Fidget",
    "CubeFidget.webp",
    "Cube fidget toy: 5x5 cube with movable small cubes, satisfying sound and feeling, useful when you want to have something to do when bored."
  );
  createProduct(
    "Impossible passthrough",
    "Impossible passthrough.webp",
    "Impossible passthrough: A mindbending satisfaction to show off to people! "
  );
  createProduct(
    "Quantum Skull",
    "Quantum Skull.webp",
    "Quantum Skull: An advanced and elaborate skull that is amazing and extremely cool!"
  );
  createProduct(
    "Headphone stand",
    "Headphone Stand.webp",
    "Headphone stand: Need a place to store your headphones? This 3D print has got YOU covered!"
  );